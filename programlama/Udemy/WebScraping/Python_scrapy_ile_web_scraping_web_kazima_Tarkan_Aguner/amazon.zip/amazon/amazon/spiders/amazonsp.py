# -*- coding: utf-8 -*-
import scrapy


class AmazonspSpider(scrapy.Spider):
    name = 'amazonsp'
    allowed_domains = ['amazon.com']
    custom_setting = {
            'FEED_URI':'veriler.json',
            'FEED_FORMAT':'json'
                     }
    def start_requests(self):
        url='https://www.amazon.com/s?k=smartphones&i=mobile&rh=n%3A2335752011%2Cn%3A7072561011%2Cn%3A2407749011%2Cp_n_feature_twenty_browse-bin%3A17881876011&dc&qid=1599427775&rnid=2335752011&ref=sr_nr_n_1'
        yield scrapy.Request(url)
    def parse(self, response):
        marka = response.xpath('.//span[@class="a-size-medium a-color-base a-text-normal"]/text()').extract()
        yield {'brand':marka}
