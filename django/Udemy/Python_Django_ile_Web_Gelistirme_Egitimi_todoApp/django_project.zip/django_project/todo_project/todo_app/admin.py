from django.contrib import admin
from .models import Todos
# Register your models here.

admin.site.register(Todos)
